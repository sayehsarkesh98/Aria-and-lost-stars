---
name: aria-game-regression-qa
description: Use when creating a test plan, reproducing a bug, checking regressions, validating a modified Aria and the Lost Stars HTML build, or testing stages, bosses, save/load, menus, cutscenes, graphics modes, and browser console errors.
---

# Aria Regression QA Engineer

Validate the game as a complete interactive product, not just a code snippet. Read `references/project-map.md`, inspect the current HTML and any included test scripts, and test the actual output file.

## Test strategy
Start with a risk-based smoke test, then targeted regression tests. Every change should have at least one test that would fail if the bug/requirement returned.

### Core startup and navigation
- Open the output file and check for page errors and console errors.
- Confirm the title/menu renders, starts a new run, resumes a saved run when offered, pauses/resumes, opens settings, and returns to menus.
- Exercise retry/checkpoint, death/game-over, stage-clear transition, next stage, victory, and ending flow as appropriate.

### Stage and combat coverage
- Cover stages across different themes and layouts: early platforming, an icy/cave stage, a later high-difficulty stage, the Reaper encounter, and the final Void Singularity arena/cutscene.
- Check platform collisions, spikes/lava/hazards, moving platforms, projectiles, power-ups/stars, player damage/invulnerability, boss shield/HP/phase transitions, and end-of-stage conditions.
- Verify stage transitions never leave stale particles, cutscenes, timers, or boss references that crash the next stage.

### Persistence and options
- Test fresh profile and existing `aria_*` localStorage data.
- Test new run, auto-save, resume after reload, export/import, and save-folder behavior only in browsers that support its APIs and after confirming permission flows.
- Test settings persistence (difficulty, audio/volume, key remapping, graphics/effects, costumes/upgrades as relevant).
- Treat malformed or outdated save data as a test case; loading must fail safely rather than destroy unrelated storage.

### Input/device matrix
- Keyboard: default bindings, remapping, keyup/focus loss, pause, and simultaneous movement/jump/shoot/dash.
- Gamepad: connect/disconnect, button mapping, analog/digital movement where supported, and pause/navigation.
- Touch: multitouch, jump/shoot/dash combinations, portrait rotation guidance, landscape canvas fit, safe areas, and browser gesture suppression.
- Resize/orientation/fullscreen where relevant.

### Rendering and performance
- Check effects presets/fallbacks, DPR 1 and 2 where available, title/menu, HUD, hit-stop/flash, boss scenes, and visual state transitions.
- For render-only changes, compare logical game state with the visual flag enabled/disabled when a deterministic test is feasible.

## Use existing helpers carefully
The provided patch archive includes historical scripts such as `test_bg.py`, `test_g.py`, `test_interp.py`, `test_pf.py`, `test_pl.py`, and `test_play_shot.py`. Before running them:
1. inspect the script header/arguments;
2. confirm Python and Playwright/browser dependencies are available;
3. verify whether its expected HTML revision matches the target;
4. adapt it narrowly if necessary;
5. report command/output honestly.

## Bug report template
- Expected behavior
- Actual behavior
- Exact stage/state/device/browser and steps to reproduce
- Console/page errors
- Minimal suspected cause (clearly label speculation)
- Regression test that reproduces the issue
- Fix and test result

Never report “all tests passed” unless the tests were actually run. Distinguish static inspection, scripted test, and human playtest.
