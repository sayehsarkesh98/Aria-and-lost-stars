---
name: aria-canvas-performance
description: Use when profiling, optimizing, or debugging FPS, stutter, high-DPI rendering, Canvas draw cost, glow/bloom, background caches, particles, post-processing, or adaptive graphics quality in Aria and the Lost Stars.
---

# Aria Canvas Performance Engineer

Optimize the existing Canvas renderer without degrading the art direction or changing game simulation.

## First steps
1. Read `references/project-map.md` and inspect the current frame/render path.
2. Separate the cost of update/simulation, background generation, entity drawing, post-processing, and Canvas resize/DPR.
3. Establish a reproducible baseline before changing code. Record device/browser, viewport, devicePixelRatio, stage, graphics preset, measurement method, and average/worst frame cost where possible.

## Non-negotiable constraints
- Keep simulation at its intended fixed-step behavior and do not use render `dt` to silently alter gameplay.
- Drawing functions must not move objects, resolve collisions, alter health, consume inputs, or advance combat timers.
- Do not introduce `Math.random()` into render-only functions; random draw calls can change gameplay randomness and invalidate deterministic comparisons.
- Preserve quality fallbacks and the ability to turn costly effects off or down on slow devices.
- Do not replace polished cached sprites/backgrounds with per-frame gradients, expensive shadowBlur calls, repeated large offscreen renders, or extra full-canvas filters without profiling.
- Maintain crisp HUD/text where post-effects are involved; avoid applying bloom/grain/aberration over UI unless clearly intended.
- Always restore Canvas state. Audit globalAlpha, transform, composite operation, filter, line styles, clipping, and text styles for leakage.

## Optimization loop
1. Measure first and select one demonstrated bottleneck.
2. Prefer reuse/caching of stable geometry, pre-rendered glow sprites, bounded particle counts, selective redraw, or fewer expensive state changes where appropriate.
3. Define cache invalidation rules. Any cache depending on stage/theme/size/DPR/quality must be rebuilt when those inputs change.
4. Benchmark before/after under identical conditions. Use warm-up runs and enough frames to avoid relying on one noisy sample.
5. Compare screenshots at normal and high DPR, on several distinct stages and the final boss scene.
6. Check both quality-on and fallback modes; verify settings still toggle correctly.
7. Confirm that logical state is identical for render-only changes when deterministic tests are available.

## Existing test ideas
The source archive has historical Playwright/Python helpers including `test_g.py`, `test_bg.py`, `test_pf.py`, `test_pl.py`, `test_interp.py`, and `perf_*` scripts. Inspect each script and target version before running it. They are reference tools, not proof that tests have passed on a new output.

## Success criteria
Report measured improvement and quality trade-offs, not just “optimized.” If a stable baseline cannot be measured, describe the change as a hypothesis and avoid claiming a specific FPS gain. Include the tested stage(s), DPR, graphics settings, and whether simulation parity was checked.
