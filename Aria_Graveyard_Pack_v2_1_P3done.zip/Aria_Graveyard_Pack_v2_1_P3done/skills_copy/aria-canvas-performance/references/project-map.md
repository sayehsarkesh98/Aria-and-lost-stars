# Aria and the Lost Stars — Project Map

## What this project is
- A self-contained browser game called **Aria and the Lost Stars**, implemented as one HTML file (`Aria_and_the_Lost_Stars_v19.html`).
- No framework or external runtime library is required by the game file itself; the main source is inline HTML/CSS/JavaScript and the game is drawn to a Canvas.
- Logical canvas coordinates are 1000×600 (the game layout uses `W`/`H` and a `#game` canvas). The CSS scales it responsively, including touch-oriented/mobile layouts.
- Gameplay: 13-stage 2D star-shooting platformer; exploration/platforming, enemies, collectible stars, power-ups, boss fights, multiple difficulty levels, upgrades, cutscenes, skins/wardrobe, sound/music, persistence, and save/backup UI.
- Boss/story highlights: stage 5 Shadow Witch, stage 10 Crimson Reaper, stage 13 Void Singularity / black-hole finale.
- Inputs include keyboard, gamepad, and touch controls. The UI includes fullscreen, screenshots, graphics/effects options, and a save/backup screen.

## Main architecture landmarks
- `genLayout(n, ...)`: builds a stage layout.
- `load(n)`, `begin()`, `retry()`, `go()`, `nextStar()`: stage/run lifecycle and initialization.
- `update()`: simulation/gameplay update, usually driven by a fixed-step accumulator in the frame loop.
- `draw0()`: main render composition.
- `frame()`: animation-frame orchestration; includes update stepping, interpolation/post processing, and drawing.
- `bgBuild()`, `bg()`: background generation/rendering and caching.
- `dPlayer()`, `dPlFx()`, `dPlat()`, `dPG()`, `dEnemy()`, `dBoss()`, `dHUD()`, `screen()`: renderer/visual layers.
- `bossAI()`, plus boss-specific helpers such as `reapStart()`, `reapX()`, and Void Singularity rendering/cutscene functions: boss behavior and presentation.
- `DEF`, `KB`, `pKey()`, `pAct()`, `pad()`, `gdStep()`, `ipOn()/ipOff()`: controls, gamepad handling, and interpolation/render support.
- `snapRun()`, `continueRun()`, `pack()`, `sane()`, `applyData()`, `saveNow()`, `tickSave()`, `openSave()`, `fs*()`: save, restore, and backup flow.

## Important global concepts (verify in the latest HTML before edits)
- `pl`: player state. Rendering should not modify gameplay coordinates, velocities, collision geometry, or hitboxes.
- `P`, `E`, `S`, `bs`, `bl`, `pj`, `pt`, `gl`: commonly used collections/state for platforms, enemies, stars/collectibles, boss, projectiles, particles, and glow/visuals. Confirm exact usage in the current source before relying on any name.
- `stage`, `st`, `tick`, `score`, `hp`, `D`, `TH`, `DF`: stage/state/time/scoring/health/difficulty/theme data.
- A developer mode is enabled by a `?dev` query parameter; inspect the current source to determine the precise debug features exposed.
- Rendering/performance toggles seen in the code include `FXON`, `PF_ON`, `PL_ON`, `BG_ON`, `H_ON`, `G_ON`, `IP_ON`, plus adaptive quality / DPR controls such as `DPR_CAP` and `AQ_MIN`. Do not assume any flag exists in every revision; verify first.
- Save data is stored in `localStorage` keys prefixed with `aria_`; some browser save-folder functionality uses IndexedDB and the File System Access API.

## Design and engineering constraints
1. Treat the current uploaded HTML file as the source of truth. This map is orientation only, not a substitute for reading the latest file.
2. Preserve the single-file, self-contained distribution unless the user explicitly asks for a modular project/build system.
3. Prefer surgical edits over regenerating the whole HTML file. Preserve original mechanics, visuals, menus, save compatibility, controls, and version-specific behavior unless the request requires a change.
4. Strictly separate simulation from rendering. A visual-only change should not modify `pl`, enemies, collision bounds, combat outcomes, input state, random-number sequence, or stage progression.
5. Avoid introducing `Math.random()` or gameplay mutation in draw functions; it can make simulation nondeterministic or desynchronize tests/interpolation.
6. Be cautious with Canvas state (`save`/`restore`, transforms, alpha, composite mode, clipping, filters) and offscreen cache invalidation.
7. Do not add dependencies, remote assets, telemetry, network calls, or build tooling without explicit approval.
8. Never claim browser testing, screenshots, performance measurements, or parity checks were completed unless actually run and observed.

## Existing test/patch assets in the user's archive
The uploaded archive includes `v19_patches_A5_H.zip`, with a `v19_patches/` folder. It contains prior HTML snapshots, patch scripts, and Playwright/Python test/benchmark scripts such as `test_bg.py`, `test_g.py`, `test_interp.py`, `test_pf.py`, `test_pl.py`, and `test_play_shot.py`. These are useful starting points, but inspect their expected source version, usage, and dependencies before running or adapting them. Do not assume every test fits a changed revision without checking.

## Definition of a good change
- The requested behavior works and the change is appropriately scoped.
- The game still loads without JavaScript errors.
- No regression in stage flow, game over/retry, boss/cutscene transitions, pause/menu, input, and save/restore.
- Rendering improvements do not mutate gameplay state.
- Low-performance devices retain a workable effects fallback.
- The final answer names the changed file, summarizes edits, lists tests actually performed and their results, and calls out any untested areas.
