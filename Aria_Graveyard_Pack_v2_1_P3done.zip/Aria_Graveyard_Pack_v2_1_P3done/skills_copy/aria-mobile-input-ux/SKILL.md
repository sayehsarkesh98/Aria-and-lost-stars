---
name: aria-mobile-input-ux
description: Use when fixing keyboard/gamepad/touch input, key remapping, mobile landscape layout, touch controls, safe-area sizing, fullscreen, orientation prompts, focus/blur, or responsive Canvas UI for Aria and the Lost Stars.
---

# Aria Input and Mobile UX Specialist

Maintain consistent, responsive controls across keyboard, gamepad, and touch for the current single-file game. Read `references/project-map.md` and inspect the actual input/event code before changing it.

## Input architecture and principles
- Verify `DEF`, `KB`, `pKey()`, `pAct()`, `pad()`, `gdStep()`, touch elements such as `#tc`, `#rc`, `#sc`, and the input-state reset handlers in the current source before editing.
- Use one logical action layer for movement, jump, shoot/aim, dash, skills, pause, and menu navigation whenever the architecture permits; avoid device-specific duplicate gameplay logic.
- Ensure simultaneous inputs work (for example movement + jump + shoot), pointer/touch events do not stick after release, and focus loss/visibility change clears held keys safely.
- Preserve key remapping and persisted `aria_*` settings.
- Do not bind browser navigation shortcuts or prevent unrelated browser behavior outside the game surface without reason.

## Mobile layout requirements
- Test both landscape and portrait. Respect the game's intended landscape hint while making the prompt clear and dismissible.
- Keep the playfield visible and the action controls reachable without covering important HUD/boss information unnecessarily.
- Respect safe-area insets on notched devices and avoid accidental scrolling/zooming while the player is using game controls; keep touch handling scoped to the game controls.
- Test multi-touch: movement/jump and shoot/dash can be held concurrently; one finger releasing must not cancel another active finger's action.
- Ensure CSS scaling of the displayed Canvas does not break pointer-to-logical-coordinate mapping.
- Controls should have distinguishable visual states, readable labels/icons, enough spacing, and feedback when pressed/cooling down/disabled.

## Gamepad and accessibility checks
- Test connect/disconnect, focus, button navigation, axis dead zones, and safe return to keyboard/touch behavior.
- Avoid making color the sole means of identifying an action; use stable icon/position/label cues.
- Maintain visible fullscreen/pause/graphics controls without stealing gameplay focus.
- Verify browser resize, orientation changes, fullscreen entry/exit, and window blur do not leave the game paused unexpectedly or leave actions held.

## Delivery requirements
For each fix, state supported input modes and tested viewport/orientation. Include at least one regression scenario for simultaneous input and one for release/focus loss. If no real mobile device or gamepad is available, explicitly label those checks as unverified and describe browser emulation used instead.
