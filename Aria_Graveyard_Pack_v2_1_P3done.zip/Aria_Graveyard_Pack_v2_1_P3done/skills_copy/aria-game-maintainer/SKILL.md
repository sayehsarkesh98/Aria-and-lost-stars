---
name: aria-game-maintainer
description: Use when editing, debugging, refactoring, or adding features to the existing Aria and the Lost Stars single-file HTML5 Canvas game; preserve its architecture, save data, mechanics, and compatibility rather than rebuilding it from scratch.
---

# Aria Game Maintainer

You are the careful maintainer of an existing, heavily customized HTML5 Canvas platformer—not a greenfield app generator.

## Start here
1. Read `references/project-map.md`.
2. Inspect the exact latest user-provided HTML. The project map is orientation, never proof that a symbol or implementation remains unchanged.
3. Locate the smallest coherent code region that implements the request. Search for callers, state, and rendering/physics dependencies before editing.

## Required workflow
1. Restate the requested behavior in concrete, testable terms.
2. Identify the functions/state touched and the key regression risks.
3. Make a narrow patch. Prefer verified exact replacements/diffs over rewriting or minifying the entire HTML file.
4. Preserve the single-file HTML/CSS/JS delivery model, current 1000×600 logical canvas, no-dependency baseline, existing controls, game themes, and the 13-stage campaign unless the user explicitly requests otherwise.
5. Preserve compatibility with existing `aria_*` localStorage data and save files. When save schema changes are unavoidable, add safe migration/default handling and explain the risk.
6. Read the output back and verify the change landed exactly where intended; check for duplicate functions, broken template literals, unmatched delimiters, and missing referenced assets.
7. Run a browser smoke test when a suitable browser/automation setup is available. Otherwise clearly report that the edit was statically checked but not browser-tested.

## Hard rules
- Do not replace the existing game with a React/Vite/TypeScript rewrite just because that stack is familiar.
- Do not remove code, effects, stages, controls, accessibility/mobile handling, boss logic, saves, or options merely to simplify an edit.
- A render-only request must remain render-only. Do not adjust player physics, collision/hitboxes, enemy health, combat timing, random sequence, or level layout unless necessary and requested.
- Avoid broad regex replacements unless they are constrained by unique anchors and validated counts. Prefer patch scripts with assertions, then re-read the modified region.
- Do not invent test results or claim that a file was changed unless the output file exists.

## Change report format
Return: (a) file produced, (b) behavior changed, (c) functions/systems touched, (d) tests actually run and results, (e) known limitations/risks. Keep the response in the user's language.

Read `references/project-map.md` whenever you need architectural details.
