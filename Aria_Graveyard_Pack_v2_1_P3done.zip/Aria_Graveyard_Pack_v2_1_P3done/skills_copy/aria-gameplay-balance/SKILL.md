---
name: aria-gameplay-balance
description: 'Use when tuning Aria and the Lost Stars gameplay: platform layouts, jump/dash feel, enemy behavior, star collection, power-ups, stage difficulty, checkpoints, combat readability, or the Shadow Witch, Crimson Reaper, and Void Singularity boss encounters.'
---

# Aria Gameplay and Encounter Designer

Design changes as an iterative game designer for the existing 13-stage star-shooting platformer. Keep its cosmic fantasy identity and learnability while improving fairness, flow, mastery, and spectacle.

## Grounding
- Read `references/project-map.md` and inspect the current game source before proposing constants or edits.
- Identify whether the request concerns traversal, combat, enemies, collectibles, upgrades, a specific stage, or a boss phase.
- Treat names and tunables in the project map as leads to verify, not guaranteed interfaces.

## Design principles
1. **Readable before difficult.** Telegraph dangerous attacks before damage; distinguish hazard colors/shapes; make safe zones and recovery windows understandable.
2. **Skill, not surprise.** Avoid unavoidable damage, hidden collision traps, attacks that require impossible reactions, or mechanics that contradict the game's controls.
3. **Progression curve.** Early stages teach one mechanic at a time; mid-game recombines prior mechanics; late stages test mastery without relying only on inflated health/speed.
4. **Fair boss loops.** For every boss attack, define: tell/telegraph, active danger, recovery/counter window, intended counterplay, and failure feedback. Test stationary/camping, jumping, close-range, and ranged play styles.
5. **Difficulty modes must be meaningful.** Consider health, enemy speed/rate, boss health, power-up drops, and scoring together; avoid changing one multiplier that accidentally makes another mode easier or harder in an unrelated way.
6. **Controls teach mechanics.** Any new move must state its input, cooldown/resource cost, range, and failure condition. Keep keyboard, gamepad, and touch affordances in mind.
7. **Theme consistency.** Use the existing six theme palettes and unique stage/boss identity. New mechanics and visuals should support the stage fantasy rather than feel randomly grafted on.

## Safe implementation process
- First offer a short design spec: player goal, rules, feedback/telegraph, success condition, failure cases, and tuning variables.
- Prefer data-driven tuning to duplicating long branches, but do not create a new architecture just for a small balance adjustment.
- Separate tunable parameters from logic where practical, and document expected trade-offs.
- Change one main variable family per iteration (for example, boss wind-up timing before also changing damage and health).
- Keep physics and collision geometry unchanged unless the task is specifically about movement/collisions.

## Required test matrix
For a gameplay edit, check as applicable:
- low and high player skill / Easy, Normal, Hard;
- ground vs airborne combat; close vs ranged; movement vs camping;
- stage start, checkpoint/retry, death, stage clear, and next stage;
- boss shield/phase/death and cutscene completion;
- mouse/keyboard, gamepad, and touch if the input changes;
- no unavoidable spawn/hazard overlap, no stuck states, no uncollectable required stars, and no accidental softlocks.

Do not call a change “balanced” based only on reading the code. Distinguish a design hypothesis from playtest evidence, and list the next telemetry/observations that would validate it.
